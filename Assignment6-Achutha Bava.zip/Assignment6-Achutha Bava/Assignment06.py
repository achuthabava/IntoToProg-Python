# -------------------------------------------------#
# Title: Assignment 6
# Dev:   Achutha Bava
# Date:  May 15, 2017
# Desc: Perform assignment 5 utilizing functions and class
# ChangeLog: (Who, When, What)
# ABava, May 15, 2017, Added New Code
# -------------------------------------------------#

class List(object):

    def usermenu(self): # usr menu function
        print('\n', "How would you like to proceed? Select an Option (1-4): \n",
              "\t #1) Show current data \n",
              "\t #2) Add a new item \n", "\t #3) Remove an existing item.\n", "\t #4) Save Data to File\n")


    def returnlist(self): # defines a function for returning the current list
        with open("/Users/achuthabava/Desktop/Introduction_to_Foundations_of_Programming/ToDo.txt") as f:
            self.mylst = []
            for line in f:  # for loop was used to process multi lines in Todo.txt
                Task, Priority = line.strip().split(',')    # first element in each row is assigned to a task and the second element of each row is assigned to priority. the elements are split using ',' delimiter.
                self.mylst.append({Task:Priority})   # each line in Todo.txt file is represented as a dictionary row and appended to mylist

            for task_priority in self.mylst:
                print('\t', task_priority)
            print('\n', '\t', "Shown below is the content of the list:\n", '\t', self.mylst)


    def additem(self): # defines a function for adding an item to the list
        newTask = input("\nEnter a new task:")
        newPriority = input("Enter a priority for the task you have entered:")
        newRow = {newTask: newPriority}
        self.mylst.append(newRow)
        print("\n\tYou have added a new item {'Task':'Priority'}:", newRow, "\n\tYour current list is:", self.mylst, '\n')


    def removetask(self): # defines a function for removing an item to the list
        strTaskname = input("\nEnter task name that you want to remove:")
        index = 0
        found = 0
        for row in self.mylst:  # for loop was written to check mylst if the queried task name is present. if found .pop() syntax was used to remove the task and associated priority level of the associated index. if task name is not found the loop returns 'not found'.
            for key in row.keys():
                if key == strTaskname:
                    found = 1
                    break
            if found:
                self.mylst.pop(index)
                print("\n your task is removed successfully and your new list is shown below: \n", '\t', self.mylst)
                break
            index += 1
        if found == 0:
            print("\n Cannot find your task")


    def savelist(self): # defines a function for saving the current list
        f = open("/Users/achuthabava/Desktop/Introduction_to_Foundations_of_Programming/ToDo.txt", "w")
        for row in self.mylst:
            for key in row.keys():
                f.writelines('%s - %s \n' % (key, row[key]))
        f.close()
        print("\nYou have exited the program and your data has been saved!")

def main():

    l=List()
    l.returnlist()
    l.usermenu()

    while (True):
        intUserEntry = int(input("\nSelect an Option: "))

        if intUserEntry == 1:
            l.returnlist()

        if intUserEntry == 2:
            l.additem()
            continue

        elif intUserEntry == 3:
            l.removetask()
            continue

        elif intUserEntry == 4:
            l.savelist()
            break

if __name__ == "__main__":
    main()
