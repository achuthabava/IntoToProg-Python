# -------------------------------------------------#
# Title: Assignment05
# Dev:   Achutha Bava
# Date:  May 08, 2017
# Desc: <Type a description of the script>
# ChangeLog: (Who, When, What)
# ABava, May 08, 2017, Added New Code
# -------------------------------------------------#


# 2. When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)

with open("/Users/achuthabava/Desktop/Introduction_to_Foundations_of_Programming/ToDo.txt") as f:
    myLst = []  # myLst is defined as an array where each row contains a task and priority of the task
    for line in f:  # for loop was used to process multi lines in Todo.txt
        Task, Priority = line.strip().split(',')    # first element in each row is assigned to a task and the second element of each row is assigned to priority. the elements are split using ',' delimiter.
        myLst.append({Task:Priority})   # each line in Todo.txt file is represented as a dictionary row and appended to mylist

    print('\n', "Each line in Todo.txt is represented as a dictionary row:",)
    for task_priority in myLst:
        print ('\t', task_priority)


# 3. After you get the data in a Python dictionary, Add the new dictionary ìrowî into a Python list object (now the data will be managed as a table).

    # myLst = [] syntax was used to add each dictionary row into an array.


# 4. Display the contents of the List to the user.
    print('\n', "Shown below is the content of the list:\n", '\t', myLst)


# 5. Allow the user to Add or Remove tasks from the list using numbered choices.
# Menu of Options
# 1. Show current data
# 2. Add a new item.
# 3. Remove an existing item.
# 4. Save Data to File
# 5. Exit Program

print('\n', "How would you like to proceed? Please select from the numbered choices: \n", "\t #1) Show current data \n",
      "\t #2) Add a new item \n", "\t #3) Remove an existing item.\n", "\t #4) Save Data to File\n",
      "\t #5) Exit Program\n")  # Prints the list of choices to the user

while (True):
    intUserEntry = int(input("Enter a Number: "))  # input() syntax was used to allow a user to an integer entry

    if intUserEntry == 1:
        # Executes the following statement if user selects Option 1
        print("\n The current data is: \n", '\t', myLst, '\n')
        continue  # Continue statement was used to contine with the next cycle of the loop

    elif intUserEntry == 2:
        # Executes the following statement if user selects Option 2
        newTask = input("\nEnter a new task:")    # asks the user for the task name
        newPriority = input("Enter a priority for the task you have entered:")  # asks the user to input priority of the entered task
        newRow = {newTask:newPriority}  # new row of data entered by the user is represented as a dictionary, {'Task':'Priority'}
        myLst.append(newRow)  # .append() syntax was used to add an element to the list object
        print("\n\tYou have added a new item {'Task':'Priority'}:", newRow, "\n\tYour current list is:", myLst, '\n')
        continue

    elif intUserEntry == 3:
        # Executes the following statement if user selects Option 3
        strTaskname = input("\nEnter task name that you want to remove:")
        index = 0
        found = 0
        for row in myLst:   #for loop was written to check mylst if the queried task name is present. if found .pop() syntax was used to remove the task and associated priority level of the associated index. if task name is not found the loop returns 'not found'.
            for key in row.keys():
                if key == strTaskname:
                    found = 1
                    break
            if found:
                myLst.pop(index)
                print ("\n your task is removed successfully and your new list is shown below: \n", '\t', myLst)
                break
            index += 1
        if found == 0:
            print ("\n Cannot find your task")
        continue

    elif intUserEntry == 4:
        # Executes the following statement if user selects Option 4
        f = open("/Users/achuthabava/Desktop/Introduction_to_Foundations_of_Programming/ToDo.txt", "w")
        for row in myLst:
            for key in row.keys():
                f.writelines('%s, %s \n' % (key, row[key])) # Reads each row in myLst and prints it as in the following format: Task, Priority
        f.close()
        print("\nYour data has been saved!\n")
        continue

    elif intUserEntry == 5:
        # Executes the following statement if user selects Option 5
        print("\nYou have exited the program, Goodbye!")
        break  # break statement was used to exit the loop

# 6. Save the data from the table into the Todo.txt file when the program exits.

    elif intUserEntry == 6:
        # Executes the following statement if user selects Option 6
        f = open("/Users/achuthabava/Desktop/Introduction_to_Foundations_of_Programming/ToDo.txt", "w")
        for row in myLst:
            for key in row.keys():
                f.writelines('%s, %s \n' % (key, row[key]))
        f.close()
        print("\nYou have exited the program and your data has been saved!")
        break
